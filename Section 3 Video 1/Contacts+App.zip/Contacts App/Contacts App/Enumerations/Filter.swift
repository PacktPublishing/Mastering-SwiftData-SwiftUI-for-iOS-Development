//
//  Filter.swift
//  Contacts App
//
//  Created by Ron Erez on 18/01/2025.
//

enum Filter {
    case none
    case exampleDomain
    case withPhoneNumber
    case startingWithA
}
