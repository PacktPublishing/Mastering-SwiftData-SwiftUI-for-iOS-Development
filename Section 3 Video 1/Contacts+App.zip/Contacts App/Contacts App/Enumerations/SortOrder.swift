//
//  SortOrder.swift
//  Contacts App
//
//  Created by Ron Erez on 18/01/2025.
//

enum SortOrder {
    case firstName, lastName, phoneNumber
}
