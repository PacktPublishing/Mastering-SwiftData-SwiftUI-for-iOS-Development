//
//  Contacts_AppApp.swift
//  Contacts App
//
//  Created by Ron Erez on 18/01/2025.
//

import SwiftUI

@main
struct Contacts_AppApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
