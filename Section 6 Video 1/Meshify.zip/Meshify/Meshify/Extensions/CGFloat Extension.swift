//
//  CGFloat Extension.swift
//  Meshify
//
//  Created by Ron Erez on 16/03/2025.
//

import Foundation

extension CGFloat {
    func toDim(_ dim: CGFloat) -> Float {
        var x = self / dim
        
        // Clamp between 0 and 1
        if x < 0 {
            x = 0
        } else if x > 1 {
            x = 1
        }
        
        // Round to nearest thousandth
        x = (x * 1000).rounded() / 1000
        
        return Float(x)
    }
}
