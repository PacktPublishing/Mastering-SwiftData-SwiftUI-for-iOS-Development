//
//  Email Validation.swift
//  Meshify
//
//  Created by Ron Erez on 01/02/2025.
//

import Foundation

extension String {
    var isValidIdentifier: Bool {
        // Non-empty: The string must be non-empty
        guard !self.isEmpty else { return false }
        
        // Starts with a letter or underscore
        let firstCharacter = self.first!
        if !firstCharacter.isLetter && firstCharacter != "_" {
            return false
        }
        
        // Remaining characters is a letter, digit or underscore
        let validCharacters = self
            .allSatisfy { $0.isLetter || $0.isNumber || $0 == "_" }
        if !validCharacters {
            return false
        }
        
        // We made it! self is a valid identifier!
        return true
    }
}
