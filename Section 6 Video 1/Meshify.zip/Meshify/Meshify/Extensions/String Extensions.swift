//
//  String Extensions.swift
//  Meshify
//
//  Created by Ron Erez on 19/03/2025.
//

import SwiftUI

extension String {
    func toColor() -> Color {
        Color.namesToColor(colorName: self)
    }
}
