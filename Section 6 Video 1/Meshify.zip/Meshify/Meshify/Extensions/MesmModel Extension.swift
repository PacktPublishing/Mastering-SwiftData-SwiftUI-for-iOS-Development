//
//  MesmModel Extension.swift
//  Meshify
//
//  Created by Ron Erez on 15/03/2025.
//

import SwiftUI

extension MeshModel {
    func toMesh() -> MeshGradient {
        MeshGradient(
            width: self.col,
            height: self.row,
            points: self.points,
            colors: Color.namesToColors(colorNames: self.colorNames),
            background: Color.namesToColor(colorName: self.bgColor), 
            smoothsColors: self.smoothColors,
            colorSpace: self.colorSpace
        )
    }
}
