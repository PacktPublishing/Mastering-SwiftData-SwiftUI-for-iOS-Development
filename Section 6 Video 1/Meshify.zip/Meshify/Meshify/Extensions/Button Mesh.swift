//
//  Button Mesh.swift
//  Meshify
//
//  Created by Ron Erez on 15/03/2025.
//

import SwiftUI

extension MeshGradient {
    static let buttonMesh = MeshGradient(
        width: 4,
        height: 4,
        points: [
            [0, 0], [0.33, 0], [0.67, 0], [1, 0],
            [0, 0.33], [0.33, 0.33], [0.67, 0.33], [1, 0.33],
            [0, 0.67], [0.33, 0.67], [0.67, 0.67], [1, 0.67],
            [0, 1], [0.33, 1], [0.67, 1], [1, 1],
        ],
        colors: [
            .green, .green, .green, .green,
            .blue, .red, .purple, .yellow,
            .gray, .gray, .red, .pink,
            .white, .cyan, .blue, .purple,
        ]
    )
}
