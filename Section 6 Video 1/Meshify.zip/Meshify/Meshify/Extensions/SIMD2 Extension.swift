//
//  SIMD2 Extension.swift
//  Meshify
//
//  Created by Ron Erez on 15/03/2025.
//

import Foundation

extension SIMD2 where Scalar == Float {
    static func defaultPoints(rows: Int , cols: Int) -> [SIMD2<Float>] {
        var points: [SIMD2<Float>] = []
        
//        guard rows > 1, cols > 1 else {
//            print("rows and columns must be greater than one")
//            return [SIMD2<Float>(0,0)]
//        }
//        
        for row in 0..<rows {
            for col in 0..<cols {
                let normalizeX: Float = cols > 1 ? Float(cols - 1) : 1
                let normalizeY: Float = rows > 1 ? Float(rows - 1) : 1
                
                let x = Float(col) / normalizeX
                let y = Float(row) / normalizeY
                
                points.append(SIMD2<Float>(x, y))
            }
        }
        
        
        return points
    }
}
