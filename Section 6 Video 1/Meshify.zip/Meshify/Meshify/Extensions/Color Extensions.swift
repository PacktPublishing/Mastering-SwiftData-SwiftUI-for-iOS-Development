//
//  Color Extensions.swift
//  Meshify
//
//  Created by Ron Erez on 15/03/2025.
//

import Foundation
import SwiftUI

extension Color {
    static let colorToName: [Color: String] = [
        .teal: "teal", .red: "red", .orange: "orange", .yellow: "yellow",
        .green: "green", .blue: "blue", .purple: "purple", .pink: "pink",
        .brown: "brown", .gray: "gray", .black: "black", .white: "white",
        .cyan: "cyan", .indigo: "indigo", .mint: "mint"
    ]
    
    static var mainColorNames: [String] {
        Array(colorToName.values)
    }
    
    static func randomColorMatrix(rows: Int, cols: Int) -> [String] {
        (0..<rows*cols)
            .map { _ in
                mainColorNames.randomElement() ?? "clear"
            }
    }
    
    static func namesToColor(colorName: String) -> Color {
        Color.nameToColor[colorName] ?? .clear
    }
    
    static func namesToColors(colorNames: [String]) -> [Color] {
        colorNames.compactMap { Color.nameToColor[$0] }
    }
    
    // Inverse dictionary of colorToName
    static var nameToColor: [String: Color] {
        Dictionary(uniqueKeysWithValues: colorToName.map { ($1, $0) })
    }
    
}
