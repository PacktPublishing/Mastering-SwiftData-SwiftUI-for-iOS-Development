//
//  CodeType.swift
//  Meshify
//
//  Created by Ron Erez on 14/03/2025.
//


enum CodeType {
    case simple, extended
}