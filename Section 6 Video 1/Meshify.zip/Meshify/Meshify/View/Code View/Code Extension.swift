//
//  Code Extension.swift
//  Meshify
//
//  Created by Ron Erez on 14/03/2025.
//

import Foundation

extension MeshModel {
    var viewName: String {
        if name.isValidIdentifier {
            return name.replacingOccurrences(of: " ", with: "_")
        } else {
            return "MyMeshView"
        }
    }
    
    var backgroundCode: String {
        bgColor == "clear" ? "" : ",\n\tbackground: .\(bgColor)"
    }
    
    var smoothColorsCode: String {
        if smoothColors {
            return ""
        } else {
            return ",\n\tsmoothsColors: false"
        }
    }
    
    var colorSpaceCode: String {
        if colorSpaceIsDevice {
            return ""
        } else {
            return ",\n\tcolorSpace: .perceptual"
        }
    }
    
    var simpleCode: String {
        var result =
                """
        MeshGradient(
                     width: \(col),
                     height: \(row),
                     points: \(pointsAsCode(points: points, rows: row, cols: col)),
                     colors: \(colorsAsCode(colors: colorNames, rows: row, cols: col))
        """
        result += backgroundCode
        result += smoothColorsCode
        result += colorSpaceCode
        result += "\n)"
        
        return result
    }
    
    func code(codeType: CodeType) -> String {
        switch codeType {
        case .extended:
            """
 import SwiftUI

 struct \(viewName): View {
     var body: some View {
        \(indent(str: simpleCode))
     }
 }

 #Preview {
      \(viewName)()
         .ignoresSafeArea()
 }
"""
        case .simple:
            simpleCode
        }
    }
    
    // Indent every line of a string
    func indent(str: String) -> String {
        let lines = str.components(separatedBy: .newlines)
        var result = ""
        result += lines.map { line in
            "\t\t\(line)"
        }.joined(separator: "\n")
        
        return result
    }
    
    
    
    
    func pointAsCode(point: SIMD2<Float>, precision: Int = 2) -> String {
        var result: String
        
        // TODO: Improve result using `precision`
        result = "[\(point.x), \(point.y)], "
        
        return result
    }
    
    func pointsAsCode(points: [SIMD2<Float>], rows: Int, cols: Int) -> String {
        let rows = (0..<rows).map { i in
            let rowPoints = (0..<cols).map { j in pointAsCode(point: points[j + i * cols]) }
            
            return "\t\t" + rowPoints.joined()
        }
        return "[\n" + rows.joined(separator: "\n") + "\n\t\t]"
    }
    
    func colorsAsCode(colors: [String], rows: Int, cols: Int) -> String {
        let rows = (0..<rows).map { i in
            let rowColors = (0..<cols).map { j in
                ".\(colors[j + i * cols]), "
            }
            
            return "\t\t\t" + rowColors.joined()
        }
        return "[\n" + rows.joined(separator: "\n") + "\n\t\t]"
    }
}
