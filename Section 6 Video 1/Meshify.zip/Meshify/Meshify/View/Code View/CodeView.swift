//
//  CodeView.swift
//  Meshify
//
//  Created by Ron Erez on 31/01/2025.
//

import SwiftUI

struct CodeView: View {
    let meshModel: MeshModel
    let codeType: CodeType
    
    var code: String {
        meshModel
            .code(codeType: codeType)
    }
    
    var body: some View {
        ScrollView {
            Text(code)
                .padding()
                .font(.title)
                .padding()
                .background(Color.white)
                .clipShape(.rect(cornerRadius: 15))
                .onDrag {
                    NSItemProvider(object: code as NSItemProviderWriting)
                }
        }.frame(minHeight: 600)
            .frame(maxWidth: .infinity)
            .padding()
    }
}

#Preview {
    CodeView(
        meshModel: MeshModel.sampleMesh(),
        codeType: .extended
    )
}

/*
 import SwiftUI

 struct WindView: View {
     var body: some View {
         MeshGradient(
             width: 4,
             height: 4,
             points: [
                 [0, 0], [0.33, 0], [0.67, 0], [1, 0],
                 [0, 0.33], [0.33, 0.33], [0.67, 0.33], [1, 0.33],
                 [0, 0.67], [0.33, 0.67], [0.67, 0.67], [1, 0.67],
                 [0, 1], [0.33, 1], [0.67, 1], [1, 1],
                 ],
             colors: [
                 .green, .green, .green, .green,
                 .blue, .red, .purple, .yellow,
                 .gray, .gray, .red, .pink,
                 .black, .black, .black, .black,
                 ],
             background: .clear
         )
     }
 }

 #Preview {
     WindView()
         .ignoresSafeArea()
 }
 */
