//
//  MeshConfigureView.swift
//  Meshify
//
//  Created by Ron Erez on 15/03/2025.
//

import SwiftUI

struct MeshConfigureView: View {
    @Binding var row: Int
    @Binding var col: Int
    @Binding var meshName: String
    
    var onDismiss: () -> Void
    
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Create New Mesh")
                .font(.title)
                .bold()
            
            TextField("Mesh Name", text: $meshName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.bottom)
            
            Section {
                HStack {
                    Picker(
                        "Rows",
                        selection: $row) {
                            ForEach(2...10, id: \.self) { num in
                                Text("\(num)").tag(num)
                            }
                        }
                        
                    Picker(
                        "Columns",
                        selection: $col) {
                            ForEach(2...10, id: \.self) { num in
                                Text("\(num)").tag(num)
                            }
                        }
                }
            } header: {
                Text("Dimensions").bold()
            }
            
            HStack {
                
                Button("Cancel") {
                    dismiss()
                }.keyboardShortcut(.cancelAction)
                    .frame(maxWidth: .infinity)
                
                Button(
                    "Create") {
                        onDismiss()
                        dismiss()
                    }
                    .keyboardShortcut(.defaultAction)
                    .disabled(!meshName.isValidIdentifier)
                    .frame(maxWidth: .infinity)
            }
        }.padding()
            .frame(width: 300)
    }
}

#Preview {
    MeshConfigureView(
        row: .constant(3),
        col: .constant(3),
        meshName: .constant("AmazingMesh"),
        onDismiss: {}
    )
}
