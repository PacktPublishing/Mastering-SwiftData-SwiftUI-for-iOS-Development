//
//  MeshListRowView.swift
//  Meshify
//
//  Created by Ron Erez on 15/03/2025.
//

import SwiftUI

struct MeshListRowView: View {
    let meshModel: MeshModel
    let isSelected: Bool
    
    var meshGradient: MeshGradient {
        meshModel.toMesh()
    }
    var text: String {
        meshModel.description
    }
    let dim: CGFloat = 35.0
    var backgroundColor: Color {
        isSelected ? .blue.opacity(0.5) : .clear
    }
    
    var body: some View {
        HStack {
            RoundedRectangle(cornerRadius: 5)
                .fill(meshGradient)
                .frame(width: dim, height: dim)
                
            Text(text)
                .font(.title)
                .minimumScaleFactor(0.1)
                .lineLimit(1)
            
            Spacer()
            
            Text(meshModel.dim)
                .font(.headline)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(backgroundColor)
                .shadow(
                    color: backgroundColor,
                    radius: 10
                ).animation(
                    .easeInOut(
                        duration: 0.2
                    ),
                    value: isSelected
                )
        )
    }
}

#Preview {
    VStack {
        MeshListRowView(
            meshModel: MeshModel.sampleMesh(),
            isSelected: true
        )
        MeshListRowView(
            meshModel: MeshModel.sampleMesh(),
            isSelected: false
        )
    }.padding()
}
