//
//  IconListRowView.swift
//  Meshify
//
//  Created by Ron Erez on 15/03/2025.
//

import SwiftUI

struct IconListRowView: View {
    let meshModel: MeshModel
    let isSelected: Bool
    
    var meshGradient: MeshGradient {
        meshModel.toMesh()
    }
    var text: String {
        meshModel.description
    }
    var borderColor: Color {
        isSelected ? .red : .clear
    }
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(meshGradient)
                .strokeBorder(borderColor, lineWidth: 5)
            Text(text)
                .font(isSelected ? .largeTitle : .title)
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.1)
                .padding()
        }
        .aspectRatio(1, contentMode: .fit)
        .scaleEffect(isSelected ? 1 : 0.9)
    }
}

#Preview {
    VStack {
        IconListRowView(
            meshModel: MeshModel.sampleMesh(),
            isSelected: true
        )
        IconListRowView(
            meshModel: MeshModel.sampleMesh(),
            isSelected: false
        )
    }
}
