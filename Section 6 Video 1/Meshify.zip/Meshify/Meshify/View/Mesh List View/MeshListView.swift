//
//  MeshListView.swift
//  Meshify
//
//  Created by Ron Erez on 15/03/2025.
//

import SwiftUI
import SwiftData

struct MeshListView: View {
    @Environment(\.modelContext) private var modelContext
    
    @Query
    var meshModels: [MeshModel]
    
    @Binding var currentMeshModel: MeshModel
    @State private var meshToDelete: MeshModel?
    
    var meshToDeleteWarning: String {
        if let meshToDelete {
            "Are you sure you want to delete the mesh \"\(meshToDelete.name)\"? This action cannot be undone."
        } else {
            ""
        }
    }
    
    @State private var showDeleteAlert = false
    
    @State private var isEditing = false
    @State private var editName = ""
    
    var code: String {
        currentMeshModel.code(codeType: .extended)
    }
    
    enum ViewType {
        case list, icon
    }
    @State private var listType: ViewType = .icon
    
    var columns: [GridItem] {
        if listType == .icon {
            [
                GridItem(.flexible()),
                GridItem(.flexible())
            ]
        } else {
            [
                GridItem(.flexible())
            ]
        }
    }
    
    var body: some View {
        VStack {
            if meshModels.isEmpty {
                ContentUnavailableView("No Mesh Available", systemImage: "square.stack.3d.up.fill")
            } else {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(meshModels) { meshModel in
                            let isSelected = currentMeshModel == meshModel
                            ZStack {
                                if listType == .list {
                                    MeshListRowView(meshModel: meshModel, isSelected: isSelected)
                                } else {
                                    IconListRowView(meshModel: meshModel, isSelected: isSelected)
                                }
                            }
                            .gesture(
                                TapGesture(count: 2).onEnded {
                                    print("DOUBLE TAP")
                                    showEditAlert(meshModel)
                                }.exclusively(before: TapGesture(count: 1).onEnded {
                                    print("SINGLE TAP")
                                    changeMesh(meshModel: meshModel)
                                })
                            )
                            .onDrag({ NSItemProvider(object: code as NSItemProviderWriting)})
                            .contextMenu {
                                Button("Rename") { showEditAlert(meshModel) }
                                Button("Duplicate") { duplicateMesh(meshModel) }
                                Button("Delete", role: .destructive) {
                                    meshToDelete = meshModel
                                    showDeleteAlert = true
                                }
                            }
                        }
                    }
                }.padding(.horizontal)
            }
        }
        .alert(meshToDeleteWarning, isPresented: $showDeleteAlert) {
            Button("Cancel", role: .cancel, action: {})
            Button("Delete", role: .destructive) {
                if let mesh = meshToDelete {
                    currentMeshModel = getPreviousMeshModel(meshModel: mesh)
                    deleteMesh(mesh)
                    meshToDelete = nil
                }
            }
        }
        .alert("Edit Mesh Name", isPresented: $isEditing) {
            TextField("New Name", text: $editName)
            Button("Save") {
                updateMeshName()
            }
        }
        .toolbar {
            Picker("", selection: $listType) {
                Image(systemName: "square.grid.2x2").tag(ViewType.icon)
                Image(systemName: "list.bullet").tag(ViewType.list)
            }.pickerStyle(.segmented)
                .padding()
        }
        .navigationSplitViewColumnWidth(
            min: 150,
            ideal: 50,
            max: 600
        ).frame(minWidth: 200, maxWidth: 400)
    }
    
    private func updateMeshName() {
        currentMeshModel.name = editName
        do {
            try modelContext.save()
        } catch {
            print("Update name error - \(error)")
        }
    }
    
    private func duplicateMesh(_ meshModel: MeshModel) {
        let duplicateMesh = MeshModel(
            name: meshModel.name + "Copy",
            row: meshModel.row,
            col: meshModel.col,
            bgColor: meshModel.bgColor,
            smoothColors: meshModel.smoothColors,
            colorSpaceIsDevice: meshModel.colorSpaceIsDevice,
            colorArray: meshModel.colorNames,
            points: meshModel.points
        )
        
        modelContext.insert(duplicateMesh)
        do {
            try modelContext.save()
        } catch {
            print("Duplicate mesh failed - \(error)")
        }
        
        
    }
    
    private func showEditAlert(_ meshModel: MeshModel) {
        changeMesh(meshModel: meshModel)
        
        editName = meshModel.name
        isEditing = true
    }

    private func changeMesh(meshModel: MeshModel) {
        currentMeshModel = meshModel
    }
    
    
    func getPreviousMeshModel(meshModel: MeshModel) -> MeshModel {
        if let index = meshModels.firstIndex(of: meshModel), index > 0 {
            return meshModels[index-1]
        } else {
            return MeshModel.sampleMesh()
        }
    }
    
    func deleteMesh(_ mesh: MeshModel) {
        modelContext.delete(mesh)
        do {
            try modelContext.save()
        } catch {
            print("Delete error - \(error)")
        }
    }
}
