//
//  MeshDetailView.swift
//  Meshify
//
//  Created by Ron Erez on 31/01/2025.
//

import SwiftUI

struct MeshDetailView: View {
    @Environment(\.modelContext) private var modelContext
    
    @Binding var selectedRow: Int
    @Binding var selectedCol: Int
    @Binding var currentMeshModel: MeshModel
    
    @State private var storeHideCode: Bool = false
    @State private var dragStarted: Bool = false
    
    @State private var hideCode: Bool = true
    @State private var extendedCode: Bool = true
    
    var codeType: CodeType {
        extendedCode ? .extended : .simple
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Checkerboard Background in case .clear
                CheckerBoardView()
                
                currentMeshModel
                    .toMesh()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                if !hideCode {
                    CodeView(
                        meshModel: currentMeshModel,
                        codeType: codeType
                    )
                    .opacity(0.7)
                }
            }
            .gesture(
                dragGesture(
                    width: geometry.size.width,
                    height: geometry.size.height
                )
            )
        }
        .toolbar {
            ToolbarItem {
                Toggle(
                    "Show code",
                    systemImage: hideCode ? "eye" : "eye.slash",
                    isOn: $hideCode.animation()
                )
            }
            
            ToolbarItem {
                Toggle(
                    "Extended Code",
                    systemImage: "chevron.left.forwardslash.chevron.right",
                    isOn: $extendedCode.animation()
                )
            }
            
            ToolbarItem {
                Button {
                    withAnimation {
                        currentMeshModel.resetPoints()
                    }
                } label: {
                    Image(systemName: "arrow.uturn.left.circle.fill")
                        .imageScale(.large)
                        .foregroundStyle(.black)
                        .background(Color.white)
                        .clipShape(Circle())
                }
            }
        }
        .padding()
    }
    
    private func dragGesture(width: CGFloat, height: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 0.1, coordinateSpace: .global)
            .onChanged { gesture in
                withAnimation {
                    if !dragStarted {
                        dragStarted = true
                        storeHideCode = hideCode
                        hideCode = true
                    }
                }
                
                let index = selectedCol + selectedRow * currentMeshModel.col
                
                // Update current mesh model
                currentMeshModel
                    .sortedColorPointPairs[index].x = gesture.location.x.toDim(width)
                
                currentMeshModel
                    .sortedColorPointPairs[index].y = gesture.location.y.toDim(height)
                
                
            }
            .onEnded { _ in
                hideCode = storeHideCode
                dragStarted = false
            }
    }
}

#Preview {
    MeshDetailView(
        selectedRow: .constant(0),
        selectedCol: .constant(0),
        currentMeshModel: .constant(MeshModel.sampleMesh())
    )
}
