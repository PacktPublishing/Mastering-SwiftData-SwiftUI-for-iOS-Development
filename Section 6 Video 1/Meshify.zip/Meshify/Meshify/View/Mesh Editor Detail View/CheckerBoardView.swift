//
//  CheckerBoardView.swift
//  Meshify
//
//  Created by Ron Erez on 16/03/2025.
//

import SwiftUI

struct CheckerBoardView: View {
    let size: CGFloat
    let color: Color?
    
    init(size: CGFloat = 10.0, color: Color? = nil) {
        self.size = size
        self.color = color
    }
    
    var body: some View {
        if let color {
            Rectangle()
                .fill(color)
        } else {
            Canvas {
                context,
                size in
                let rows = Int(size.height / self.size)
                let cols = Int(size.width / self.size)
                
                for row in 0..<rows {
                    for col in 0..<cols {
                        if (row + col) % 2 == 0 {
                            let rect = CGRect(
                                x: CGFloat(col) * self.size,
                                y: CGFloat(row) * self.size,
                                width: self.size,
                                height: self.size
                            )
                            context
                                .fill(
                                    Path(rect),
                                    with: .color(.gray.opacity(0.3))
                                )
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    VStack {
        CheckerBoardView()
        CheckerBoardView(color: .red)
    }
}
