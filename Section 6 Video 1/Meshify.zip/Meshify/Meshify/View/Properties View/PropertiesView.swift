//
//  PropertiesView.swift
//  Meshify
//
//  Created by Ron Erez on 17/03/2025.
//

import SwiftUI

struct PropertiesView: View {
    @Binding var selectedRow: Int
    @Binding var selectedCol: Int
    @Binding var currentMeshModel: MeshModel
    
    @State private var colorSpace: Gradient.ColorSpace = .device
    @State private var smoothColors: Bool = true
    @State private var showBackground = true
    @State private var showBGPopover = false
    
    var backgroundTitle: String {
        showBackground ? "Set Background Color" : "Background Color is Clear"
    }
    
    var body: some View {
        Form {
            Section {
                TextField("Mesh Name", text: $currentMeshModel.name)
            } header: {
                Text("Mesh Name").bold()
            }

            Section {
                SelectionView(
                    meshModel: $currentMeshModel,
                    selectedRow: $selectedRow,
                    selectedCol: $selectedCol
                )
            } header: {
                Text("Control Points").bold()
            }

            Section {
                Picker(
                    "Color Space",
                    selection: $currentMeshModel.colorSpaceIsDevice) {
                        Text("Device").tag(true)
                        Text("Perceptual").tag(false)
                    }
                    .pickerStyle(.segmented)
            } header: {
                Text("Color Space").bold()
            }
            
            Section {
                Toggle(
                    "Smooths Colors",
                    isOn: $currentMeshModel.smoothColors
                )
            } header: {
                Text("Smooths Colors").bold()
            }
            
            Section {
                if showBackground {
                    CheckerBoardView(color: currentMeshModel.bgColor == "clear" ? nil : currentMeshModel.bgColor.toColor())
                        .frame(height: 50)
                        .frame(maxWidth: .infinity)
                        .onTapGesture {
                            showBGPopover.toggle()
                        }
                        .popover(
                            isPresented: $showBGPopover,
                            arrowEdge: .bottom) {
                                ColorSelectionView(selectedColor: $currentMeshModel.bgColor)
                            }
                }
            } header: {
                HStack {
                    Text(backgroundTitle).bold()
                    Spacer()
                    Toggle("", isOn: $showBackground)
                        .labelsHidden()
                        .onChange(of: showBackground) { _, showBackgroundValue in
                            if !showBackgroundValue {
                                currentMeshModel.bgColor = "clear"
                            }
                        }
                }
            }
        }
        .frame(minWidth: 400)
        .padding()
    }
}

#Preview {
    PropertiesView(
        selectedRow: .constant(0),
        selectedCol: .constant(0),
        currentMeshModel: .constant(MeshModel.sampleMesh())
    )
}
