//
//  PopoverOnTapModifier.swift
//  Meshify
//
//  Created by Ron Erez on 06/03/2025.
//


import SwiftUI

struct PopoverModifier<PopoverContent: View>: ViewModifier {
    @Binding var isPresented: Bool
    let popoverContent: () -> PopoverContent
    
    func body(content: Content) -> some View {
        content
            .popover(isPresented: $isPresented, arrowEdge: .bottom, content: popoverContent)
    }
}

extension View {
    func popoverView<PopoverContent: View>(
        isPresented: Binding<Bool>,
        @ViewBuilder popoverContent: @escaping () -> PopoverContent
    ) -> some View {
        self
            .popover(isPresented: isPresented, arrowEdge: .bottom, content: popoverContent)
    }
}

