//
//  ColorSelectionView.swift
//  Meshify
//
//  Created by Ron Erez on 19/03/2025.
//

import SwiftUI

struct ColorSelectionView: View {
    @Binding var selectedColor: String
    let numColumns: Int
    let dim: CGFloat
    let columns: [GridItem]
    let colorLibrary: [String]
    
    init(
        selectedColor: Binding<String>,
        numColumns: Int = 5,
        dim: CGFloat = 40.0,
        colorLibrary: [String] = Color.mainColorNames
    ) {
        self._selectedColor = selectedColor
        self.numColumns = numColumns
        self.dim = dim
        self.columns = Array(
            repeating: GridItem(.fixed(dim*5/4)),
            count: numColumns
        )
        self.colorLibrary = colorLibrary
    }
    
    var body: some View {
        VStack {
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(colorLibrary, id: \.self) { colorName in
                    Circle()
                        .fill(colorName.toColor())
                        .frame(width: dim, height: dim)
                        .onTapGesture {
                            selectedColor = colorName
                        }
                        .overlay {
                            Circle()
                                .stroke(
                                    .black,
                                    lineWidth: selectedColor == colorName ? 3 : 0.3
                                ).shadow(radius: 3)
                        }
                }
            }
            .padding()
        }.padding()
            .background(.ultraThinMaterial, in: .rect(cornerRadius: 20))
            
    }
}

#Preview {
    @Previewable @State var selectedColor: String = "red"
    @Previewable @State var showBGPopover = false
    
    
    VStack {
        ColorSelectionView(selectedColor: .constant("red"))
        
        ColorSelectionView(selectedColor: .constant("red"), numColumns: 4, dim: 30)
        
        Text("Selected Color: \(selectedColor)")
            .padding()
            .background(.gray.opacity(0.2), in: .rect(cornerRadius: 8))
            .onTapGesture {
                showBGPopover.toggle()
            }
            .popover(isPresented: $showBGPopover, arrowEdge: .bottom) {
                ColorSelectionView(selectedColor: $selectedColor, numColumns: 5, dim: 30)
            }
    }
}
