//
//  SquareView.swift
//  Meshify
//
//  Created by Ron Erez on 20/03/2025.
//

import SwiftUI

struct SquareView: View {
    let color: Color
    let isSelected: Bool
    let dim = 50.0
    
    var lineWidth: CGFloat {
        isSelected ? 2 : 0.5
    }
    var shadowColor: Color {
        isSelected ? .white : .clear
    }
    var scale: CGFloat {
        isSelected ? 1.2 : 1
    }
    
    var body: some View {
        RoundedRectangle(cornerRadius: 15)
            .fill(color.opacity(0.8))
            .overlay {
                RoundedRectangle(cornerRadius: 15)
                    .strokeBorder(.black, lineWidth: lineWidth)
            }
            .shadow(color: shadowColor, radius: 5)
            .scaleEffect(scale)
            .frame(width: dim, height: dim)
            .padding()
    }
}

#Preview {
    VStack {
        SquareView(color: .red, isSelected: false)
        SquareView(color: .red, isSelected: true)
    }
}
