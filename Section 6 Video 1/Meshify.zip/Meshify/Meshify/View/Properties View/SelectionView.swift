//
//  SelectionView.swift
//  Meshify
//
//  Created by Ron Erez on 20/03/2025.
//

import SwiftUI

struct GridPosition: Hashable {
    let row: Int
    let col: Int
}

struct SelectionView: View {
    @Binding var meshModel: MeshModel
    @Binding var selectedRow: Int
    @Binding var selectedCol: Int
    
    @State private var showPopover = false
    @State private var newColorName: String = ""
    @State private var selectedPopoverPosition: GridPosition? = nil
    
    let numColumns = 5
    let dim: CGFloat = 40.0
    let columns: [GridItem]
    
    init(
        meshModel: Binding<MeshModel>,
        selectedRow: Binding<Int>,
        selectedCol: Binding<Int>
    ) {
        self._meshModel = meshModel
        self._selectedRow = selectedRow
        self._selectedCol = selectedCol
        self.columns = Array(
            repeating: GridItem(.fixed(dim * 5/4)),
            count: numColumns
        )
    }
    
    var body: some View {
        VStack {
            Text("Select a Point")
                .font(.headline)
            
            Grid {
                ForEach(0..<meshModel.row, id: \.self) { i in
                    GridRow {
                        ForEach(0 ..< meshModel.col, id: \.self) { j in
                            let isSelected = selectedRow == i && selectedCol == j
                            let position = GridPosition(row: i, col: j)
                            let isPopoverActive = selectedPopoverPosition == position
                            
                            SquareView(
                                color: meshModel.colorNames[j + i * meshModel.col].toColor(),
                                isSelected: isSelected
                            ).popover(
                                isPresented: Binding(
                                    get: { isPopoverActive },
                                    set: { if !$0 { selectedPopoverPosition = nil } }
                                )) {
                                    ColorSelectionView(
                                        selectedColor: $newColorName,
                                        numColumns: 5,
                                        dim: 30
                                    )
                                }
                                .onTapGesture {
                                    selectedPopoverPosition = isPopoverActive ? nil : position
                                    selectedRow = position.row
                                    selectedCol = position.col
                                    newColorName = meshModel.colorNames[j + i * meshModel.col]
                                }
                                .onChange(of: newColorName) { _, _ in
                                    meshModel
                                        .sortedColorPointPairs[selectedCol + selectedRow * meshModel.col]
                                        .colorName = newColorName
                                }
                                
                        }
                    }
                }
            }
        }
        .padding()
    }
}

#Preview {
    SelectionView(
        meshModel: .constant(MeshModel.sampleMesh()),
        selectedRow: .constant(1),
        selectedCol: .constant(2)
    )
}
