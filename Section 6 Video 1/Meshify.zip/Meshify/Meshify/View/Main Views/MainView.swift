//
//  ContentView.swift
//  Meshify
//
//  Created by Ron Erez on 31/01/2025.
//

import SwiftUI
import SwiftData

struct MainView: View {
    @Environment(\.modelContext) private var modelContext
    
    @Query(sort: \MeshModel.name, order: .forward)
    private var meshModels: [MeshModel]
    
    @State private var currentMeshModel: MeshModel = MeshModel.sampleMesh()
    @State private var isPresented: Bool = true
    
    // Parameters for mesh configure view
    @State private var newMeshName: String = ""
    @State private var newRow: Int = 2
    @State private var newCol: Int = 2
    
    @State private var showDialog: Bool = false
    
    @State private var selectedRow: Int = 0
    @State private var selectedCol: Int = 0
    
    var body: some View {
        NavigationSplitView {
            MeshListView(currentMeshModel: $currentMeshModel)
        } detail: {
            if meshModels.isEmpty {
                MeshModel.sampleMesh().toMesh()
            } else {
                MeshDetailView(
                    selectedRow: $selectedRow,
                    selectedCol: $selectedCol,
                    currentMeshModel: $currentMeshModel
                )
            }
        }
        .inspector(isPresented: $isPresented) {
            PropertiesView(
                selectedRow: $selectedRow,
                selectedCol: $selectedCol,
                currentMeshModel: $currentMeshModel
            )
            .inspectorColumnWidth(
                min: 0,
                ideal: 225,
                max: 800
            )
        }
        .onAppear {
            if !meshModels.isEmpty {
                currentMeshModel = meshModels[0]
            }
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                Button {
                    showDialog = true
                } label: {
                    Text("New Mesh")
                        .foregroundStyle(.white)
                        .font(.title)
                        .shadow(radius: 5)
                }
                .background(MeshGradient.buttonMesh)
                .clipShape(.rect(cornerRadius: 10))
                .shadow(radius: 5)
                .help("Create New Mesh")
            }
        }
        .sheet(isPresented: $showDialog) {
            MeshConfigureView(
                row: $newRow,
                col: $newCol,
                meshName: $newMeshName) {
                    let colorArray: [String] = Color.randomColorMatrix(
                        rows: newRow,
                        cols: newCol
                    )
                    
                    // Evenly distributed default points
                    let points: [SIMD2<Float>] = SIMD2
                        .defaultPoints(
                            rows: newRow,
                            cols: newCol
                        )
                    
                    currentMeshModel = MeshModel(
                        name: newMeshName,
                        row: newRow,
                        col: newCol,
                        colorArray: colorArray,
                        points: points
                    )
                    
                    modelContext
                        .insert(currentMeshModel)
                    
                    do {
                        try modelContext.save()
                    } catch {
                        print("Error on save: \(error)")
                    }
                    
                    newMeshName = ""
                }
        }
    }
}

#Preview {
    MainView()
        .modelContainer(for: MeshModel.self)
}
