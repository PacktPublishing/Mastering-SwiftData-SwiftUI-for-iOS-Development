//
//  BeautifulMesh.swift
//  Meshify
//
//  Created by Ron Erez on 23/03/2025.
//


 import SwiftUI

 struct BeautifulMesh: View {
     var body: some View {
        		MeshGradient(
		             width: 3,
		             height: 3,
		             points: [
				[0.0, 0.0], [0.5, 0.0], [1.0, 0.0], 
				[0.0, 0.5], [0.305, 0.446], [1.0, 0.5], 
				[0.0, 1.0], [0.5, 1.0], [1.0, 1.0], 
				],
		             colors: [
					.mint, .cyan, .white, 
					.teal, .mint, .red, 
					.purple, .pink, .white, 
				]
		)
     }
 }

 #Preview {
      BeautifulMesh()
         .ignoresSafeArea()
 }