//
//  MyMesh.swift
//  Meshify
//
//  Created by Ron Erez on 23/03/2025.
//


 import SwiftUI

 struct MyMesh: View {
     var body: some View {
        		MeshGradient(
		             width: 3,
		             height: 3,
		             points: [
				[0.0, 0.0], [0.5, 0.0], [1.0, 0.0], 
				[0.0, 0.5], [1.0, 0.124], [1.0, 0.5], 
				[0.0, 1.0], [0.5, 1.0], [1.0, 1.0], 
				],
		             colors: [
					.yellow, .cyan, .white, 
					.teal, .black, .red, 
					.purple, .pink, .white, 
				]
		)
     }
 }

 #Preview {
      MyMesh()
         .ignoresSafeArea()
 }