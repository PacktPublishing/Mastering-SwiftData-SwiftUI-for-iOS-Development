
import SwiftUI

struct Wind: View {
    var body: some View {
               MeshGradient(
                    width: 4,
                    height: 4,
                    points: [
               [0.0, 0.0], [0.33, 0.0], [0.67, 0.0], [1.0, 0.0],
               [0.0, 0.33], [0.33, 0.33], [0.67, 0.33], [1.0, 0.33],
               [0.0, 0.67], [0.33, 0.67], [0.67, 0.67], [1.0, 0.67],
               [0.0, 1.0], [0.33, 1.0], [0.67, 1.0], [1.0, 1.0],
               ],
                    colors: [
                   .green, .green, .green, .green,
                   .blue, .red, .purple, .yellow,
                   .gray, .gray, .red, .pink,
                   .black, .black, .black, .black,
               ],
           background: .red,
           smoothsColors: false
       )
    }
}

#Preview {
     Wind()
        .ignoresSafeArea()
}
