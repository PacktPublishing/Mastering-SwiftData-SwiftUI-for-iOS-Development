//
//  Great.swift
//  Meshify
//
//  Created by Ron Erez on 16/03/2025.
//


 import SwiftUI

 struct Great: View {
     var body: some View {
        		MeshGradient(
		             width: 2,
		             height: 2,
		             points: [
				[0.0, 0.0], [1.0, 0.0], 
				[0.0, 1.0], [1.0, 1.0], 
				],
		             colors: [
					.pink, .indigo, 
					.red, .indigo, 
				]
		)
     }
 }

 #Preview {
      Great()
         .ignoresSafeArea()
 }