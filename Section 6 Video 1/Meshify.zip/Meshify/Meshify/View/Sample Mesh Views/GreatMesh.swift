//
//  GreatMesh.swift
//  Meshify
//
//  Created by Ron Erez on 23/03/2025.
//


 import SwiftUI

 struct GreatMesh: View {
     var body: some View {
        		MeshGradient(
		             width: 3,
		             height: 3,
		             points: [
				[0.871, 0.46], [0.5, 0.0], [1.0, 0.0], 
				[0.0, 0.5], [0.157, 0.279], [1.0, 0.424], 
				[0.205, 0.758], [0.5, 1.0], [0.801, 0.646], 
				],
		             colors: [
					.mint, .cyan, .indigo, 
					.teal, .mint, .brown, 
					.cyan, .pink, .white, 
				],
			background: .indigo
		)
     }
 }

 #Preview {
      GreatMesh()
         .ignoresSafeArea()
 }