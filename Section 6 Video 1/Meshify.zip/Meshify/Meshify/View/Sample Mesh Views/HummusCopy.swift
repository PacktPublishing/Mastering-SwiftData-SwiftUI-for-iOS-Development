//
//  HummusCopy.swift
//  Meshify
//
//  Created by Ron Erez on 16/03/2025.
//


 import SwiftUI

 struct HummusCopy: View {
     var body: some View {
        		MeshGradient(
		             width: 2,
		             height: 3,
		             points: [
				[0.0, 0.0], [1.0, 0.0], 
				[0.0, 0.5], [1.0, 0.5], 
				[0.0, 1.0], [1.0, 1.0], 
				],
		             colors: [
					.purple, .red, 
					.red, .green, 
					.brown, .black, 
				]
		)
     }
 }

 #Preview {
      HummusCopy()
         .ignoresSafeArea()
 }