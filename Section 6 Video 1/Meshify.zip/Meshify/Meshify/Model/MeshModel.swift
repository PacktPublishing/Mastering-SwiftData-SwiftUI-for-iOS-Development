//
//  MeshModel.swift
//  Meshify
//
//  Created by Ron Erez on 31/01/2025.
//

import Foundation
import SwiftData
import SwiftUI


@Model
class ColorPointPair {
    var meshModel: MeshModel?
    
    var colorName: String
    var x: Float
    var y: Float
    var sortIndex: Int
    
    init(colorName: String, x: Float, y: Float, sortIndex: Int) {
        self.colorName = colorName
        self.x = x
        self.y = y
        self.sortIndex = sortIndex
    }

    init(colorName: String, pt: SIMD2<Float>, sortIndex: Int) {
        self.colorName = colorName
        self.x = pt.x
        self.y = pt.y
        self.sortIndex = sortIndex
    }
}

@Model
class MeshModel {
    var name: String
    var row: Int
    var col: Int
    var bgColor: String
    var smoothColors: Bool
    var colorSpaceIsDevice: Bool
    
    @Relationship(deleteRule: .cascade, inverse: \ColorPointPair.meshModel)
    private var colorPointPairs: [ColorPointPair]
    
    var sortedColorPointPairs: [ColorPointPair] {
        get {
            colorPointPairs
                .sorted { $0.sortIndex < $1.sortIndex }
        }
        set {
            colorPointPairs = newValue
        }
    }
    
    var description: String {
        name.isEmpty ? "MyMesh" : "\(name)"
    }
    
    var points: [SIMD2<Float>] {
        sortedColorPointPairs
            .map { SIMD2<Float>(x: $0.x, y: $0.y) }
    }
    
    
    var colorNames: [String] {
        sortedColorPointPairs
            .map(\.colorName)
    }
    
    var colorSpace: Gradient.ColorSpace {
        colorSpaceIsDevice ? .device : .perceptual
    }
    
    var dim: String {
        "(\(row), \(col))"
    }

    init(
        name: String,
        row: Int,
        col: Int,
        bgColor: String = "clear",
        smoothColors: Bool = true,
        colorSpaceIsDevice: Bool = true,
        colorPointPairs: [ColorPointPair]
    ) {
        self.name = name
        self.row = row
        self.col = col
        self.bgColor = bgColor
        self.smoothColors = smoothColors
        self.colorSpaceIsDevice = colorSpaceIsDevice
        self.colorPointPairs = colorPointPairs
    }
    
    init(
        name: String,
        row: Int,
        col: Int,
        bgColor: String = "clear",
        smoothColors: Bool = true,
        colorSpaceIsDevice: Bool = true,
        colorArray: [String],
        points: [SIMD2<Float>]
    ) {
        self.name = name
        self.row = row
        self.col = col
        self.bgColor = bgColor
        self.smoothColors = smoothColors
        self.colorSpaceIsDevice = colorSpaceIsDevice
        
        self.colorPointPairs = []
        let n = min(colorArray.count, points.count)
        
        for i in 0..<n {
            colorPointPairs
                .append(
                    .init(
                        colorName: colorArray[i],
                        pt: points[i],
                        sortIndex: i
                    )
                )
        }
    }
    
    func resetPoints() {
        self.setPoints(
            points: SIMD2.defaultPoints(rows: self.row, cols: self.col)
        )
    }
    
    func setPoints(points: [SIMD2<Float>]) {
        guard points.count == colorPointPairs.count else {
            print("Length mismatch error")
            return
        }
        
        for i in 0..<points.count {
            colorPointPairs[i].x = points[i].x
            colorPointPairs[i].y = points[i].y
            colorPointPairs[i].sortIndex = i
        }
    }
    
    
    static let sampleMesh = {
        let colorNames = [
            "green", "green", "green", "green",
            "blue", "red", "purple", "yellow",
            "gray", "gray", "red", "pink",
            "black", "black", "black", "black",
        ]
        
        let points: [SIMD2<Float>] = [
            [0, 0], [0.33, 0], [0.67, 0], [1, 0],
            [0, 0.33], [0.33, 0.33], [0.67, 0.33], [1, 0.33],
            [0, 0.67], [0.33, 0.67], [0.67, 0.67], [1, 0.67],
            [0, 1], [0.33, 1], [0.67, 1], [1, 1],
        ]
        
        var colorPointPairs: [ColorPointPair] = []
        for i in 0..<points.count {
            colorPointPairs
                .append(
                    .init(
                        colorName: colorNames[i],
                        pt: points[i],
                        sortIndex: i
                    )
                )
        }
        
        return MeshModel(
            name: "Wind",
            row: 4,
            col: 4,
            bgColor: "red",
            smoothColors: false,
            colorPointPairs: colorPointPairs
        )
    }
    
}

