//
//  MeshifyApp.swift
//  Meshify
//
//  Created by Ron Erez on 31/01/2025.
//

import SwiftUI

@main
struct MeshifyApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
                .modelContainer(for: MeshModel.self)
        }
    }
    
    init() {
        print(URL.applicationSupportDirectory
            .path(percentEncoded: false))
    }
}



